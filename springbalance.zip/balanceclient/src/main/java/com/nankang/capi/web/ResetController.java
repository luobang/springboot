package com.nankang.capi.web;

import org.springframework.web.bind.annotation.*;

/**
 * Created by zxc on 2019/1/23.
 */
@RestController
public class ResetController {
    @RequestMapping(value = "/api/{ope}/{params}",method = RequestMethod.GET)
    public String api(@PathVariable int ope,@PathVariable String params){
        return "params,"+params;
    }
}

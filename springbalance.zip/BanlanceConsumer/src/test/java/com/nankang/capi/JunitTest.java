package com.nankang.capi;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;

/**
 * Created by zxc on 2019/1/23.
 */
public class JunitTest {
    @Before
    public void setUp() throws Exception
    {
    }

    @After
    public void tearDown() throws Exception
    {
    }

    @Test
    public void testMain() {
        try {
            String response=HttpClientUtil.post("D:/问答系统/SpringBootTest/src/main/resources/tomcat.key", "nankang123456", "https://localhost:89/api/1/%7Brdfdf", new HashMap<>());
            System.out.print(response);
        }catch(Exception e){
            e.printStackTrace();;
        }
    }

}

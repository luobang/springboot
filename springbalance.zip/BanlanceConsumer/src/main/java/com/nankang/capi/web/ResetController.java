package com.nankang.capi.web;

import com.nankang.capi.web.bean.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by zxc on 2019/1/23.
 */
@RestController
public class ResetController {
    @Autowired
    RestTemplate restTemplate;
    /**
     * 实例化RestTemplate
     * @return
     */
    @LoadBalanced
    @Bean
    public RestTemplate rest() {
        return new RestTemplate();
    }

    @RequestMapping(value = "/api/{ope}/{params}",method = RequestMethod.POST)
    @ResponseBody
    public Result api(@PathVariable int ope,@PathVariable String params){
        Result result=new Result();
        String data = (String)restTemplate.getForObject("http://service-provider/api/"+ope+"/"+params,String.class);
        result.setData(data);
        return result;
    }
}

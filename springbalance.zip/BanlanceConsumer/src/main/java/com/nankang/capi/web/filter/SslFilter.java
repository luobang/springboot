package com.nankang.capi.web.filter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Configuration
@WebFilter
public class SslFilter extends OncePerRequestFilter {
    @Value("${tomcat.port}")
    private Integer tomcatPort;

    @Value("${https.port}")
    private Integer port;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String requestURL = request.getRequestURL().toString();
        String protocol = requestURL.split("://")[0];
        if ("http".equals(protocol)) {
            requestURL = requestURL.replace("http", "https").replace(Integer.toString(tomcatPort), Integer.toString(port));
            response.sendRedirect(requestURL);
        }
        filterChain.doFilter(request, response);
    }
}

package com.nankang;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.apache.catalina.connector.Connector;
import org.apache.coyote.http11.Http11NioProtocol;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import java.io.File;
import java.io.IOException;

@SpringBootApplication
@EnableEurekaClient
public class BalanceConsumerApplication {

	@Value("${tomcat.port}")
	private Integer tomcatPort;

	@Value("${https.port}")
	private Integer port;

	@Value("${https.ssl.key-password}")
	private String keyStorePassword;

	@Value("${https.ssl.key-password}")
	private String keyPassword;

	@Value("${https.ssl.key-type}")
	private String keyType;

	public static void main(String[] args) {
		SpringApplication.run(BalanceConsumerApplication.class, args);
	}

	@Bean
	public ServletWebServerFactory servletContainer() {
		TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory();
		tomcat.addAdditionalTomcatConnectors(createSslConnector()); // ����http
		return tomcat;
	}

	private Connector createSslConnector() {
		Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
		Http11NioProtocol protocol = (Http11NioProtocol) connector.getProtocolHandler();
		try {
			File keystore = new ClassPathResource("tomcat.key").getFile();
            /*File truststore = new ClassPathResource("sample.jks").getFile();*/
			connector.setScheme("https");
			connector.setSecure(true);
			connector.setPort(port);
			protocol.setSSLEnabled(true);
			protocol.setKeystoreType(keyType);
			protocol.setKeystoreFile(keystore.getAbsolutePath());
			protocol.setKeystorePass(keyStorePassword);
			protocol.setKeyPass(keyStorePassword);
			return connector;
		}
		catch (IOException ex) {
			throw new IllegalStateException("can't access keystore: [" + "keystore"
					+ "] or truststore: [" + "keystore" + "]", ex);
		}
	}

	@Bean
	public Connector httpConnector() {
		Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
		connector.setScheme("http");
		connector.setPort(tomcatPort);
		connector.setSecure(false);
		connector.setRedirectPort(port);
		return connector;
	}
}

